
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'juanesarango',
  applicationName: 'strika-api',
  appUid: 'y1PM33m9t0brwHmgqv',
  orgUid: 'D67S7WsQfQwT5BCtnc',
  deploymentUid: '9b1a3885-b6db-4c6c-8907-64acf9b8643a',
  serviceName: 'strika-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'strika-api-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}